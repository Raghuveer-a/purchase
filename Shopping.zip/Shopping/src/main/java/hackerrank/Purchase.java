package hackerrank;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import persistent.Item;

/**
 *	TODO: Complete the Purchase class
 */
public class Purchase {
    /**
     * Find the PurchasedItems for each of the given barcodes.
     *
     * @param itemBarcodeList A list of barcodes.
     * @return A list of PurchasedItems.
     */
    public static List<PurchasedItem> getPurchasedItemsList(List<String> itemBarcodeList) {
        // TODO: Complete the function.
    	
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemBarcodes", itemBarcodeList);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemBarcode in (:itemBarcodes)", Optional.of(parameters));
       
        // String barcode, String name, String category, Float finalPrice
        List<PurchasedItem> purchaseItems = new ArrayList<PurchasedItem>();
        for(Item item: itemsList)
        {
        	purchaseItems.add(new PurchasedItem(item.getItemBarcode(),item.getItemName(), item.getItemCategory(), item.getItemPrice() - item.getItemDiscount())); 
        }
        
        return purchaseItems;
    }

    /**
     * Find the total number of available items in the given category.
     *
     * @param category The item's category.
     * @return The number of available items in that category.
     */
    public static Integer getNumberOfAvailableItemsInCategory(String category) {
    	// TODO: Complete the function.
    	
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemCategory", category);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemCategory = :itemCategory", Optional.of(parameters));
        return itemsList.size();
    }

    /**
     * Find the total number of available items priced lower than upperLimit.
     *
     * @param upperLimit
     * @return available items with lower price than upperLimit
     */
    public static Integer getTotalAvailableLowerPricedItemsWithoutDiscount(Float upperLimit) {
    	// TODO: Complete the function.
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemPrice", upperLimit);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemPrice < :itemPrice", Optional.of(parameters));
        return itemsList.size();

    	
    }

    /**
     * Find the total number of available items priced higher than lowerLimit.
     * @param lowerLimit
     * @return available items with higher price than lowerLimit
     */
    public static Integer getTotalAvailableHigherPricedItemsWithoutDiscount(Float lowerLimit) {
    	// TODO: Complete the function.
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemPrice", lowerLimit);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemPrice > :itemPrice", Optional.of(parameters));
        return itemsList.size();

    	
    }

    /**
     * Find whether the item with the given barcode is available.
     *
     * @param barcode The item's barcode.
     * @return true if the item is available and false if it is not.
     */
    public static boolean isAvailable(String barcode) {
    	// TODO: Complete the function.
        
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("barcode", barcode);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemBarcode > :barcode", Optional.of(parameters));
        return (itemsList.size() > 0);
    }

    /**
     * Count the total number of available items.
     *
     * @return The total number of available items.
     */
    public static Integer getTotalAvailableItems() {
    	// TODO: Complete the function.
        
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemAvailablity", 1);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemAvailablity > :itemAvailablity", Optional.of(parameters));
        return itemsList.size();
    }

    /**
     * Count the total number of unavailable items.
     *
     * @return The total number of unavailable items.
     */
    public static Integer getTotalUnAvailableItems() {
    	// TODO: Complete the function.
    	HashMap<String, Object> parameters = new HashMap<>();
    	parameters.put("itemAvailablity", 0);
        ArrayList<Item> itemsList = HibernateQueryRunner.getItemsList("from Item i where i.itemAvailablity > :itemAvailablity", Optional.of(parameters));
        return itemsList.size();
    	
    }
}
